# currency-converter
Currency convert application
Will run as a cli in the terminal

currency-convert --usd 20.08
conversion rate: 1.00 USD = 15.00 ZAR, 1.00 EUR
