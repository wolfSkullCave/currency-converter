"""An application to convert Dollars(USD) into Rands(ZAR)"""

__version__ = "1.0.0-alpha"
__description__ = "A simple currency converter that uses web scraping to retrieve the exchange rate."