# currency-converter
Convert dollars(USD) to rands(ZAR)
